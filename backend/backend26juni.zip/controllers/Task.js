import db from '../config/Database.js';

export const createTask = async (req, res) => {
  const { title, description, dueDate } = req.body;
  try {
    const [result] = await db.execute(
      'INSERT INTO tasks (title, description, due_date) VALUES (?, ?, ?)',
      [title, description, dueDate]
    );
    res.status(201).json({ id: result.insertId, title, description, dueDate });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

export const updateTask = async (req, res) => {
  const { id } = req.params;
  const { title, description, dueDate } = req.body;
  try {
    const [result] = await db.execute(
      'UPDATE tasks SET title = ?, description = ?, due_date = ? WHERE id = ?',
      [title, description, dueDate, id]
    );
    if (result.affectedRows === 0) return res.status(404).json({ message: 'Task not found' });
    res.status(200).json({ id, title, description, dueDate });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

export const deleteTask = async (req, res) => {
  const { id } = req.params;
  try {
    const [result] = await db.execute('DELETE FROM tasks WHERE id = ?', [id]);
    if (result.affectedRows === 0) return res.status(404).json({ message: 'Task not found' });
    res.status(200).json({ message: 'Task deleted successfully' });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

export const uploadTask = async (req, res) => {
  const { studentId, taskId, fileUrl } = req.body;
  try {
    const [result] = await db.execute(
      'INSERT INTO task_submissions (student_id, task_id, file_url) VALUES (?, ?, ?)',
      [studentId, taskId, fileUrl]
    );
    res.status(201).json({ id: result.insertId, studentId, taskId, fileUrl });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};