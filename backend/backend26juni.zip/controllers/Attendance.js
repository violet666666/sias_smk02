import db from '../config/Database.js';

export const createAttendance = async (req, res) => {
  const { studentId, classId, date, status } = req.body;
  try {
    const [result] = await db.execute(
      'INSERT INTO attendance (student_id, class_id, date, status) VALUES (?, ?, ?, ?)',
      [studentId, classId, date, status]
    );
    res.status(201).json({ id: result.insertId, studentId, classId, date, status });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

export const markAttendance = async (req, res) => {
  const { studentId, classId, date, status } = req.body;
  try {
    const [result] = await db.execute(
      'INSERT INTO attendance (student_id, class_id, date, status) VALUES (?, ?, ?, ?)',
      [studentId, classId, date, status]
    );
    res.status(201).json({ id: result.insertId, studentId, classId, date, status });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};