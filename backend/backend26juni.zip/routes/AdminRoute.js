const express = require('express');
const router = express.Router();
const { verifyToken, checkRole } = require('../middleware/AuthUser');
const UserController = require('../controllers/Users.js');

router.post('/user', verifyToken, checkRole(['admin']), UserController.createUser);
router.put('/user/:id', verifyToken, checkRole(['admin']), UserController.updateUser);
router.delete('/user/:id', verifyToken, checkRole(['admin']), UserController.deleteUser);

module.exports = router;