import express from 'express';
import { verifyToken, checkRole } from '../middleware/AuthUser.js';
import { getDashboard } from '../controllers/Dashboard.js';

const router = express.Router();

router.get('/dashboard', verifyToken, checkRole(['orang tua']), getDashboard);

export default router;