import {Sequelize} from "sequelize";

const db = new Sequelize('db_sias', 'root', '', {
    host: "localhost",
    dialect: "mysql"
});

export default db;