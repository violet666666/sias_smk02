import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const FormAddKelas = () => {
  const [name, setName] = useState("");
  const [deskripsi, setDeskripsi] = useState("");
  const [tahun, setTahun] = useState("");
  const [status, setStatus] = useState("");
  const [periodeAwal, setPeriodeAwal] = useState("");
  const [periodeAkhir, setPeriodeAkhir] = useState("");
  const [msg, setMsg] = useState("");
  const navigate = useNavigate();

  const saveKelas = async (e) => {
    e.preventDefault();
    try {
      await axios.post("http://localhost:5000/classes", {
        name: name,
        deskripsi: deskripsi,
        tahun: tahun,
        status: status,
        periodeAwal: periodeAwal,
        periodeAkhir: periodeAkhir,
      });
      navigate("/classes");
    } catch (error) {
      if (error.response) {
        setMsg(error.response.data.msg);
      }
    }
  };

  return (
    <div>
      <h1 className="title">Kelas</h1>
      <h2 className="subtitle">Buat Kelas</h2>
      <div className="card is-shadowless">
        <div className="card-content">
          <div className="content">
            <form onSubmit={saveKelas}>
              <p className="has-text-centered">{msg}</p>
              
              <div className="field">
                <label className="label">Kelas</label>
                <div className="control">
                  <input
                    type="text"
                    className="input"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Nama Kelas"
                  />
                </div>
              </div>
             
              <div className="field">
                <label className="label">Deskripsi</label>
                <div className="control">
                  <input
                    type="text"
                    className="input"
                    value={deskripsi}
                    onChange={(e) => setDeskripsi(e.target.value)}
                    placeholder="Deskripsi Kelas"
                  />
                </div>
              </div>

              <div className="field">
                <label className="label">Tahun</label>
                <div className="control">
                  <input
                    type="text"
                    className="input"
                    value={tahun}
                    onChange={(e) => setTahun(e.target.value)}
                    placeholder="Tahun"
                  />
                </div>
              </div>

              <div className="field">
                <label className="label">Status</label>
                <div className="control">
                  <div className="select is-fullwidth">
                    <select
                      value={status}
                      onChange={(e) => setStatus(e.target.value)}
                    >
                      <option value="Aktif">Aktif</option>
                      <option value="Tidak Aktif">Tidak Aktif</option>
                    </select>
                  </div>
                </div>
              </div>

              <div className="field">
                <label className="label">Mulai</label>
                <div className="control">
                  <input
                    type="date"
                    className="input"
                    value={periodeAwal}
                    onChange={(e) => setPeriodeAwal(e.target.value)}
                    placeholder="Periode Mulai"
                  />
                </div>
              </div>

              <div className="field">
                <label className="label">Selesai</label>
                <div className="control">
                  <input
                    type="date"
                    className="input"
                    value={periodeAkhir}
                    onChange={(e) => setPeriodeAkhir(e.target.value)}
                    placeholder="Periode Berakhir"
                  />
                </div>
              </div>

              <div className="field">
                <div className="control">
                  <button type="submit" className="button is-success">
                    Simpan
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FormAddKelas;
