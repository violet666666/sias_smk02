// import { DefaultLayout } from "../../layout/DefaultLayout";


// import { useState } from "react";

// export default function DashboardSiswa() {

//     const [sidebar, setSidebar] = useState([
 
//     ])



//     return (
//         <DefaultLayout sidebar={
//             <>
//                 <div className="sidebarComponent">
//                     <div className="iconImage flex">
//                         <img src="/logo512.png" alt="logo" />
//                         <span>Ceria</span>
//                     </div>

//                 </div>
//             </>
//         }
//             content={
//                 <h1>Dashboard Siswa</h1>
//             } />
//     )
// }