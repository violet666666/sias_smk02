import { BrowserRouter, Routes, Route } from "react-router-dom";
import Dashboard from "./pages/Dashboard";
import Login from "./components/Login";
import Users from "./pages/Users";
import Classes from "./pages/Classes";
import AddUser from "./pages/AddUser";
import EditUser from "./pages/EditUser";
import AddKelas from "./pages/AddKelas";
import EditKelas from "./pages/EditKelas";
import "../src/style/App.css";

function App() {
  return (
    <div>
      <BrowserRouter>
        <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/users" element={<Users />} />
        <Route path="/users/add" element={<AddUser />} />
        <Route path="/users/edit/:id" element={<EditUser />} />
        <Route path="/classes" element={<Classes />} />
        <Route path="/classes/add" element={<AddKelas />} />
        <Route path="/classes/edit/:id" element={<EditKelas />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
