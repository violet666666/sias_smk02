import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate, useParams } from "react-router-dom";

const FormEditKelas = () => {
  const [name, setName] = useState("");
  const [deskripsi, setDeskripsi] = useState("");  
  const [tahun, setTahun] = useState("");
  const [status, setStatus] = useState("");
  const [periodeAwal, setPeriodeAwal] = useState("");
  const [periodeAkhir, setPeriodeAkhir] = useState("");
  const [msg, setMsg] = useState("");
  const navigate = useNavigate();
  const { id } = useParams();

  useEffect(() => {
    const getKelasById = async () => {
      try {
        const response = await axios.get(
          `http://localhost:5000/classes/${id}`
        );
        setName(response.data.name);
        setDeskripsi(response.data.deskripsi);
        setTahun(response.data.tahun);
        setStatus(response.data.status);
        setPeriodeAwal(response.data.periodeAwal);
        setPeriodeAkhir(response.data.periodeAkhir);
      } catch (error) {
        if (error.response) {
          setMsg(error.response.data.msg);
        }
      }
    };
    getKelasById();
  }, [id]);

  const updateKelas = async (e) => {
    e.preventDefault();
    try {
      await axios.patch(`http://localhost:5000/classes/${id}`, {
        name: name,
        tahun: tahun,
        status: status,
        periodeAwal: periodeAwal,
        periodeAkhir: periodeAkhir,
      });
      navigate("/classes");
    } catch (error) {
      if (error.response) {
        setMsg(error.response.data.msg);
      }
    }
  };

  return (
    <div>
      <h1 className="title">Kelas</h1>
      <h2 className="subtitle">Edit Kelas</h2>
      <div className="card is-shadowless">
        <div className="card-content">
          <div className="content">
            <form onSubmit={updateKelas}>
              <p className="has-text-centered">{msg}</p>
              <div className="field">
                <label className="label">Name</label>
                <div className="control">
                  <input
                    type="text"
                    className="input"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Kelas Name"
                  />
                </div>
              </div>
              
              <div className="field">
                <label className="label">Deskripsi</label>
                <div className="control">
                  <input
                    type="text"
                    className="input"
                    value={deskripsi}
                    onChange={(e) => setDeskripsi(e.target.value)}
                    placeholder="Deskripsi Kelas"
                  />
                </div>
              </div>

              <div className="field">
                <label className="label">Tahun</label>
                <div className="control">
                  <input
                    type="text"
                    className="input"
                    value={tahun}
                    onChange={(e) => setTahun(e.target.value)}
                    placeholder="Tahun"
                  />
                </div>
              </div>

              <div className="field">
                <label className="label">Status</label>
                <div className="control">
                  <input
                    type="text"
                    className="input"
                    value={status}
                    onChange={(e) => setStatus(e.target.value)}
                    placeholder="Status Kelas"
                  />
                </div>
              </div>

              <div className="field">
                <label className="label">Mulai</label>
                <div className="control">
                  <input
                    type="date"
                    className="input"
                    value={periodeAwal}
                    onChange={(e) => setPeriodeAwal(e.target.value)}
                    placeholder="Periode Mulai"
                  />
                </div>
              </div>

              <div className="field">
                <label className="label">Selesai</label>
                <div className="control">
                  <input
                    type="date"
                    className="input"
                    value={periodeAkhir}
                    onChange={(e) => setPeriodeAkhir(e.target.value)}
                    placeholder="Periode Berakhir"
                  />
                </div>
              </div>

              <div className="field">
                <div className="control">
                  <button type="submit" className="button is-success">
                    Update
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FormEditKelas;
