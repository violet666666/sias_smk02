import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "axios";

const KelasList = () => {
  const [classes, setClasses] = useState([]);

  useEffect(() => {
    getClasses();
  }, []);

  const getClasses = async () => {
    const response = await axios.get("http://localhost:5000/classes");
    setClasses(response.data);
  };

  const deleteKelas = async (kelasId) => {
    await axios.delete(`http://localhost:5000/classes/${kelasId}`);
    getClasses();
  };

  return (
    <div>
      <h1 className="title">Kelas</h1>
      <h2 className="subtitle">Daftar Kelas</h2>
      <Link to="/classes/add" className="button is-primary mb-2">
        Tambah Kelas Baru
      </Link>
      <table className="table is-striped is-fullwidth">
        <thead>
          <tr>
            <th>No</th>
            <th>Nama Kelas</th>
            <th>Tahun</th>
            <th>Status</th>
            <th>Mulai</th>
            <th>Selesai</th>
          </tr>
        </thead>
        <tbody>
          {classes.map((kelas, index) => (
            <tr key={kelas.uuid}>
              <td>{index + 1}</td>
              <td>{kelas.name}</td>
              <td>{kelas.tahun}</td>
              <td>{kelas.status}</td>
              <td>{new Date(kelas.periodeAwal).toISOString().split('T')[0]}</td>
              <td>{new Date(kelas.periodeAkhir).toISOString().split('T')[0]}</td>
              <td>
                <Link
                  to={`/classes/edit/${kelas.uuid}`}
                  className="button is-small is-info"
                >
                  Edit
                </Link>
                <button
                  onClick={() => deleteKelas(kelas.uuid)}
                  className="button is-small is-danger"
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default KelasList;
